FlowMap Painter
(c)2012 Teck Lee Tan
www.teckArtist.com

== Description ==

This here is a flowmap painter. It serves to make artist-authored (or -tweaked) flowmaps a viable option, where current methods tend to favor simulations via Houdini, for example.
(https://developer.valvesoftware.com/wiki/Water_(shader)#Authoring_a_flow_map)

The tool allows the artist to paint areas of flow, and uses a basic flow shader to immediately preview the results.
It also provides a couple of additional visualisations, such as the actual colors that are being painted, as well as a visualisation of the resulting flow lines.

It's currently a little rough around the edges; for example, needing to type in the path to your output or custom texture, as opposed to having a proper file browser.


== Installation ==

Currently (initial test release), there's no installer. Just unzip to the location of your choice and run FlowMapPainter.exe.


== Changelog ==

= 0.9 =
* 17 September 2012
* Initial test release


== ToDo ==

* Proper file browser
* Store some defaults (eg. Output directory, last session's custom texture path, etc)
* Redo functionality (currently only undo)


== Further Reading ==

https://developer.valvesoftware.com/wiki/Water_(shader)
http://mtnphil.wordpress.com/2012/08/25/water-flow-shader/
http://twvideo01.ubm-us.net/o1/vault/gdc2012/slides/Missing%20Presentations/Added%20March%2026/Keith_Guerrette_VisualArts_TheTricksUp.pdf (from P57 - Creating Motion in Particles, Technique 2: Flow Technique)